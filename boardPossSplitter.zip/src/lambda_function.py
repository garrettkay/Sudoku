import json
import copy
import boto3

def boardPossSplitter(boardName, boardInput, boardPossInput):
	board = copy.deepcopy(boardInput)
	boardPoss = copy.deepcopy(boardPossInput)
	for r in range(9):
		for c in range(9):
			if board[r][c] != 0:
				for row in range(9):
					if row != r and board[r][c] == board[row][c]:
						return ""
				for col in range(9):
					if col != c and board[r][c] == board[r][col]:
						return ""
				boxRow = r//3
				boxCol = c//3
				for bRow in range(3):
					for bCol in range(3):
						if (boxRow*3 + bRow != r or boxCol*3 + bCol != c) and board[r][c] == board[boxRow*3 + bRow][boxCol*3 + bCol]:
							return ""
	for r in range(9):
		for c in range(9):
			if len(boardPoss[r][c]) == 0:
				return ""
	solved = True
	for gRow in range(9):
		for gCol in range(9):
			if board[gRow][gCol] == 0:
				solved = False
				for guess in boardPoss[gRow][gCol]:
					tempBoard = copy.deepcopy(board)
					tempBoardPoss = copy.deepcopy(boardPoss)
					tempBoard[gRow][gCol] = guess
					for r in range(9):
						for c in range(9):
							if tempBoard[r][c] != 0:
								tempBoardPoss[r][c].clear()
								tempBoardPoss[r][c].append(tempBoard[r][c])
					change = True
					while(change):
						change = False
						for r in range(9):
							for c in range(9):
								if tempBoard[r][c] == 0:
									for row in range(9):
										if tempBoard[row][c] in tempBoardPoss[r][c]:
											tempBoardPoss[r][c].remove(tempBoard[row][c])
											change = True
									for col in range(9):
										if tempBoard[r][col] in tempBoardPoss[r][c]:
											tempBoardPoss[r][c].remove(tempBoard[r][col])
											change = True
									boxRow = r//3
									boxCol = c//3
									for bRow in range(3):
										for bCol in range(3):
											if tempBoard[boxRow*3+bRow][boxCol*3+bCol] in tempBoardPoss[r][c]:
												tempBoardPoss[r][c].remove(tempBoard[boxRow*3+bRow][boxCol*3+bCol])
												change = True
						for r in range(9):
							for c in range(9):
								if tempBoard[r][c] == 0 and len(tempBoardPoss[r][c]) == 1:
									tempBoard[r][c] = tempBoardPoss[r][c][0]
									change = True
						for num in range(1,10):
							for r in range(9):
								count = 0
								pos = 10
								br = False
								for c in range(9):
									if tempBoard[r][c] == num:
										br = True
										break
									if num in tempBoardPoss[r][c]:
										count += 1
										pos = c
								if count == 1 and not br:
									tempBoard[r][pos] = num
									tempBoardPoss[r][pos].clear()
									tempBoardPoss[r][pos].append(num)
									change = True
						for num in range(1,10):
							for c in range(9):
								count = 0
								pos = 10
								br = False
								for r in range(9):
									if tempBoard[r][c] == num:
										br = True
										break
									if num in tempBoardPoss[r][c]:
										count += 1
										pos = r
								if count == 1 and not br:
									tempBoard[pos][c] = num
									tempBoardPoss[pos][c].clear()
									tempBoardPoss[pos][c].append(num)
									change = True
						for num in range(1,10):
							for boxRow in range(3):
								for boxCol in range(3):
									count = 0
									posR = 10
									posC = 10
									br = False
									for bRow in range(3):
										for bCol in range(3):
											if tempBoard[boxRow*3 + bRow][boxCol*3 + bCol] == num:
												br = True
												break
											if num in tempBoardPoss[boxRow*3 + bRow][boxCol*3 + bCol]:
												count += 1
												posR = boxRow*3 + bRow
												posC = boxCol*3 + bCol
									if count == 1 and not br:
										tempBoard[posR][posC] = num
										tempBoardPoss[posR][posC].clear()
										tempBoardPoss[posR][posC].append(num)
										change = True

					boto3.client('lambda').invoke(
						FunctionName = 'boardPossSplitter',
						InvocationType = 'Event',
						Payload = json.dumps({
							"boardName": boardName,
							"board": tempBoard,
							"boardPoss": tempBoardPoss
					  	})
					)
				return ""
	if solved:
		boardArray = ""
		for row in board:
			boardArray += str(row) + "\n"
		boardString = str(board)
		i = 0
		while i < len(boardString):
			if not boardString[i].isdecimal():
				boardString = boardString[:i] + boardString[i + 1:]
				i -= 1
			i += 1
		boto3.client('s3').put_object(Body= boardArray + boardString, Bucket= "sudoku--solver", Key= "boardSolution/" + boardName[:-4] + "Solution" + boardName[-4:])
		return ""

def lambda_handler(event, context):
	boardPossSplitter(event["boardName"],event["board"], event["boardPoss"])