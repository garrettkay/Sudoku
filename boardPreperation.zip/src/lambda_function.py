import json
import boto3
import copy

def boardTypeSet(boardRawInput):
	i = 0
	while i < len(boardRawInput):
		if not boardRawInput[i].isdecimal():
			boardRawInput = boardRawInput[:i] + boardRawInput[i + 1:]
			i -= 1
		i += 1
	if isinstance(boardRawInput, str) and len(boardRawInput) == 81 and boardRawInput.isdecimal():
		board = []
		for i in range(9):
			tempList = []
			for j in range(9):
				tempList.append(int(boardRawInput[i * 9 + j]))
			board.append(tempList)
		return board
	return "INVALID FORMAT"

def boardPossSet(boardInput):
	boardPoss= [[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]],
				[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]],
				[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]],
				[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]],
				[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]],
				[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]],
				[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]],
				[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]],
				[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]]]
	board = copy.deepcopy(boardInput)
	for r in range(9):
		for c in range(9):
			if board[r][c] != 0:
				boardPoss[r][c].clear()
				boardPoss[r][c].append(board[r][c])
	change = True
	while(change):
		change = False
		for r in range(9):
			for c in range(9):
				if board[r][c] == 0:
					for row in range(9):
						if board[row][c] in boardPoss[r][c]:
							boardPoss[r][c].remove(board[row][c])
							change = True
					for col in range(9):
						if board[r][col] in boardPoss[r][c]:
							boardPoss[r][c].remove(board[r][col])
							change = True
					boxRow = r//3
					boxCol = c//3
					for bRow in range(3):
						for bCol in range(3):
							if  board[boxRow*3+bRow][boxCol*3+bCol] in boardPoss[r][c]:
								boardPoss[r][c].remove(board[boxRow*3+bRow][boxCol*3+bCol])
								change = True
		for r in range(9):
			for c in range(9):
				if board[r][c] == 0 and len(boardPoss[r][c]) == 1:
					board[r][c] = boardPoss[r][c][0]
					change = True
		for num in range(1,10):
			for r in range(9):
				count = 0
				pos = -1
				br = False
				for c in range(9):
					if board[r][c] == num:
						br = True
						break
					if num in boardPoss[r][c]:
						count = count + 1
						pos = c
				if count == 1 and not br:
					board[r][pos] = num
					boardPoss[r][pos].clear()
					boardPoss[r][pos].append(num)
					change = True
		for num in range(1,10):
			for c in range(9):
				count = 0
				pos = -1
				br = False
				for r in range(9):
					if board[r][c] == num:
						br = True
						break
					if num in boardPoss[r][c]:
						count = count + 1
						pos = r
				if count == 1 and not br:
					board[pos][c] = num
					boardPoss[pos][c].clear()
					boardPoss[pos][c].append(num)
					change = True
		for num in range(1,10):
			for boxRow in range(3):
				for boxCol in range(3):
					count = 0
					posR = -1
					posC = -1
					br = False
					for bRow in range(3):
						for bCol in range(3):
							if board[boxRow*3 + bRow][boxCol*3 + bCol] == num:
								br = True
								break
							if num in boardPoss[boxRow*3 + bRow][boxCol*3 + bCol]:
								count = count + 1
								posR = boxRow*3 + bRow
								posC = boxCol*3 + bCol
					if count == 1 and not br:
						board[posR][posC] = num
						boardPoss[posR][posC].clear()
						boardPoss[posR][posC].append(num)
						change = True
	return (board,boardPoss)

def lambda_handler(event, context):
	s3key = event["Records"][0]["s3"]["object"]["key"]
	try:
		body = boto3.client("s3").get_object(Bucket="sudoku--solver", Key=s3key)["Body"].read().decode("utf-8")
	except Exception as e:
		print("failed")
		raise e
	(newBoard, newBoardPoss) = boardPossSet(boardTypeSet(body))
	boto3.client('lambda').invoke(
    	FunctionName = 'boardPossSplitter',
    	InvocationType = 'Event',
    	Payload = json.dumps({
    		"boardName": s3key[11:],
			"board": newBoard,
			"boardPoss": newBoardPoss
    	})
	)